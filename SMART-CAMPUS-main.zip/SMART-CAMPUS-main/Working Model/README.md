<img width="1280" alt="Screenshot 2024-09-27 at 8 41 13 PM" src="https://github.com/user-attachments/assets/b098982f-9ef1-4238-8a90-d33ba646f7af">
<img width="1280" alt="Screenshot 2024-09-27 at 8 42 11 PM" src="https://github.com/user-attachments/assets/df6824d7-5f9c-4dfc-bf44-a6df58cf2d49">
<img width="1280" alt="Screenshot 2024-09-27 at 8 41 55 PM" src="https://github.com/user-attachments/assets/68517d18-0e10-4ab9-b699-8308290a62b7">
<img width="1280" alt="Screenshot 2024-09-27 at 8 41 48 PM" src="https://github.com/user-attachments/assets/3b482bc9-5d11-495b-bef4-eed9f1d6c964">
<img width="1280" alt="Screenshot 2024-09-27 at 8 41 41 PM" src="https://github.com/user-attachments/assets/cc8484bc-8d1f-4c42-ba72-fb0a549da7e2">
